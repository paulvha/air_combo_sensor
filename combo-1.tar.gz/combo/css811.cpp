/******************************************************************************

ORIGINAL : 

SparkFunCCS811.cpp
CCS811 Arduino library

Marshall Taylor @ SparkFun Electronics
Nathan Seidle @ SparkFun Electronics

April 4, 2017

https://github.com/sparkfun/CCS811_Air_Quality_Breakout
https://github.com/sparkfun/SparkFun_CCS811_Arduino_Library

Resources:
Uses Wire.h for i2c operation

Development environment specifics:
Arduino IDE 1.8.1

This code is released under the [MIT License](http://opensource.org/licenses/MIT).

Please review the LICENSE.md file included with this example. If you have any questions 
or concerns with licensing, please contact techsupport@sparkfun.com.

Distributed as-is; no warranty is given.
******************************************************************************
* 
* Modified December 2017 Paul van Haastrecht
* 
* Resources:
* BCM2835 library for i2C (http://www.airspayce.com/mikem/bcm2835/)
*
* Development environment specifics:
* Raspberry Pi / linux Jessie release
* 
******************************************************************************/

# include "SparkFunCCS811.h"
# include "bcm2835.h"
# include <stdlib.h>
# include <stdio.h>
# include <stdint.h>
# include <string.h>
# include <sys/types.h>
# include <stdarg.h>
# include <math.h> 

# define PROCESS_DELAY 2

//These are the air quality values obtained from the sensor
float refResistance;
float resistance;
uint16_t tVOC;
uint16_t CO2;
uint16_t vrefCounts = 0;
uint16_t ntcCounts = 0;
float temperature;


CCS811Core::CCS811Core(struct combo *com)
{
    // initialize BCM2835 information
    settings.hw_initialized = 0 ;
}

/*****************************************************
 * 
 *  perform hard-reset on CCS811
 * 
 *****************************************************/
void CCS811Core::hw_reset(void)
{
    bcm2835_gpio_write(settings.reset_gpio, LOW);
    bcm2835_delay(1000);

    bcm2835_gpio_write(settings.reset_gpio, HIGH);
    bcm2835_delay(1000);
}

/*****************************************************
 * 
 * wake_up or sleep the CCS811
 * 
 ***************************************************/
CCS811Core::status CCS811Core::wake(bool action)
{
    if (action == WAKE_UP)
        bcm2835_gpio_write(settings.wake_gpio, LOW);
        
    else if (action == SLEEP)
        bcm2835_gpio_write(settings.wake_gpio, HIGH);
    
    else
    {
        p_printf(RED, (char *) "incorrect wake request %d\n", action);
        return(SENSOR_INTERNAL_ERROR);
    }
    
    return(SENSOR_SUCCESS);
}

/**********************************************************
 * 
 * check that the CSS811 is connected to the i2C 
 * 
 *********************************************************/
CCS811Core::status CCS811Core::beginCore(void)
{
    uint8_t readCheck = 0;
    
    CCS811Core::status returnError = SENSOR_SUCCESS;
    
    returnError = readRegister(CSS811_HW_ID, &readCheck);

    if( returnError != SENSOR_SUCCESS ) return(returnError);
   
    // get Hardware ID, MUST be 0x81
    if( readCheck != 0x81 )
    {
        returnError = SENSOR_ID_ERROR;
    }

    return returnError;
}

/*********************************************************************
 *
 *  ReadRegister
 *
 *  Parameters:
 *    offset -- register to read
 *    *outputPointer -- Pass &variable (address of) to save read data to
 *
 *********************************************************************/
CCS811Core::status CCS811Core::readRegister(uint8_t offset, uint8_t* outputPointer)
{
    return(multiReadRegister(offset, outputPointer,1));
}

/**********************************************************************
 *
 *  multiReadRegister
 *
 *  Parameters:
 *    offset -- register to read
 *    *outputPointer -- Pass &variable (base address of) to save read data to
 *    length -- number of bytes to read
 *
 *  Note:  Does not know if the target memory space is an array or not, or
 *    if there is the array is big enough.  if the variable passed is only
 *    two bytes long and 3 bytes are requested, this will over-write some
 *    other memory!
 *
 **********************************************************************/
CCS811Core::status CCS811Core::multiReadRegister(uint8_t offset, uint8_t *outputPointer, uint8_t length)
{

    int     result, retry = 3;  // retry count
    CCS811Core::status returnError;
    
    // set slave address for CSS811
    bcm2835_i2c_setSlaveAddress(settings.I2CAddress);
   
    /* normally I use the BCM2835 read with restart. e.g.
     * bcm2835_i2c_read_register_rs((char *) &offset, (char *) outputPointer, length)
     * which is working great with the many other devices ( the BME280 on the same board
     * works without any problems)
     * 
     * But as soon as the application was started on CCS811, it needed MUCH more 
     * time to handle the request (returning 0xff) without errors. Hence the routine
     * has been changed to first do write, wait and then read. This way it can work on
     * 400Khz. Alternative would have been to maximize the i2C speed to max. 20khz.
     * 
     * Next to that the CCS811 regular fails with a NACK (again the BME280 is working
     * liking a star). To improve the stability, also a retry count has been implemented. 
     * 
     * Anyway we are not in a hurry... are we ? */
    
    while(1)
    {
        // first write the register we want to read
        returnError = multiWriteRegister(offset, 0,0);
        if( returnError != SENSOR_SUCCESS ) 
        {
            printf("Error during reading register %d\n",offset);
            return(returnError);
        }
        
        // give the CCS811 time to process
        bcm2835_delay(PROCESS_DELAY);
        
        // read results
        result = bcm2835_i2c_read((char *) outputPointer, length);
        
        // if failure, then retry as long as retrycount has not been reached
        if (result != BCM2835_I2C_REASON_OK)
        {
            if (retry-- > 0) continue;
        }
        
        // process result
        switch(result)
        {
            case BCM2835_I2C_REASON_ERROR_NACK :
                p_printf(RED, (char *) "NACK error\n");
                return(SENSOR_I2C_ERROR);
    
            case BCM2835_I2C_REASON_ERROR_CLKT :
                p_printf(RED,(char *)"Clock stretch error\n");
                return(SENSOR_I2C_ERROR);
                
            case BCM2835_I2C_REASON_ERROR_DATA :
                p_printf(RED,(char *)"not all data has been read\n");
                return(SENSOR_I2C_ERROR);
                
            case BCM2835_I2C_REASON_OK:
                return(SENSOR_SUCCESS);
                
            default:
                p_printf(RED,(char *) "unkown return code\n");
                return(SENSOR_I2C_ERROR);
        }
    }
}


 /********************************************************************
 *
 *  writeRegister
 *
 *  Parameters:
 *    offset -- register to write
 *    dataToWrite -- 8 bit data to write to register
 *
 *********************************************************************/
CCS811Core::status CCS811Core::writeRegister(uint8_t offset, uint8_t dataToWrite) 
{
    return(multiWriteRegister(offset, &dataToWrite, 1)); 
}


/**********************************************************************
 *
 *  multiWriteRegister
 *
 *  Parameters:
 *    offset -- register to write
 *    *inputPointer -- Pass &variable (base address of) to save read data to
 *    length -- number of bytes to write
 *
 * Note:  Does not know if the target memory space is an array or not, or
 *    if there is the array is big enough.  if the variable passed is only
 *    two bytes long and 3 bytes are requested, this will over-write some
 *    other memory!
 *
 * Note: the CCS811 was very unstable on the raspberryPi. Often resulting in
 *     NACK errors.(while the BME280 on the same board work without ANY problems) 
 *     To improve stability a retrycount has been implemented
 *
 *********************************************************************/
CCS811Core::status CCS811Core::multiWriteRegister(uint8_t offset, uint8_t *inputPointer, uint8_t length)
{
    int     result, i;
    char    buff[10];
    int     retry = 3;  // retry count
    
    if (length > 9)
    {
        p_printf(RED, (char *) "can handle up to 9 registers. Request is for %d\n", length);
        return(SENSOR_INTERNAL_ERROR);
    }
    
    // set register
    buff[0]=offset;
    
    // copy data
    for (i = 0 ; i < length; i++)  buff[i+1] = inputPointer[i];
    
    // set slave address for CSS811
    bcm2835_i2c_setSlaveAddress(settings.I2CAddress);

    while (1)
    {
        // perform a write of data
        result = bcm2835_i2c_write(buff, length+1);
    
        // if error, perform retry (if not exceeded)
        if (result != BCM2835_I2C_REASON_OK)
        {
            if (retry-- > 0) continue;
        }
        
        switch(result)
        {
            case BCM2835_I2C_REASON_ERROR_NACK :
                p_printf(RED,(char* )"write NACK error\n");
                return(SENSOR_I2C_ERROR);

            case BCM2835_I2C_REASON_ERROR_CLKT :
                p_printf(RED,(char* )"write Clock stretch error\n");
                return(SENSOR_I2C_ERROR);

            case BCM2835_I2C_REASON_ERROR_DATA :
                p_printf(RED,(char* )"write not all data has been sent\n");
                return(SENSOR_I2C_ERROR);

            case BCM2835_I2C_REASON_OK:
                return(SENSOR_SUCCESS);

            default :
                p_printf(RED,(char* )"Unkown error during writing\n");
                return(SENSOR_I2C_ERROR);
        }
    }

}

 /********************************************************************
 *
 *  Main user class -- wrapper for the core class + maths
 *
 *  Construct with same rules as the core
 *
 *********************************************************************/
CCS811::CCS811(struct combo *com ) : CCS811Core(com)
{
    refResistance = 10000;
    resistance = 0;
    temperature = 0;
    tVOC = 0;
    CO2 = 0;
}

/*********************************************************************
 *
 *  Begin
 *
 *  This starts the lower level begin, then applies settings
 * 
 ********************************************************************/
CCS811Core::status CCS811::begin( void )
{

    CCS811Core::status returnError = SENSOR_SUCCESS;    //Default return state
    uint8_t value;
    int retry = 5;

    // try to read Hardware ID
    while (1)
    {
        // wake up the CCS811
        wake(WAKE_UP);
        bcm2835_delay(100);

        //restart the core
        returnError = beginCore();

        if( returnError == SENSOR_SUCCESS ) break;
        
        if (retry-- == 0)  return(returnError);
        else
        {
            hw_reset();
            wake(SLEEP);
            bcm2835_delay(500);             
        }
     }
    
    // perform soft reset
    if( soft_reset() != SENSOR_SUCCESS ) return (SENSOR_INTERNAL_ERROR);
    
    // there for NO error
    if( checkForStatusError() == true ) return(SENSOR_INTERNAL_ERROR);
    
    // check that application is available
    if( appValid() == false ) return(SENSOR_INTERNAL_ERROR);

    // start application
    returnError  = multiWriteRegister(CSS811_APP_START, 0,0);
    if (returnError != SENSOR_SUCCESS)  return(returnError);
    
    // check that application has started
    retry = 5;
    while(1)
    {
        bcm2835_delay(100); 
        
        returnError = readRegister( CSS811_STATUS, &value );
        if (returnError != SENSOR_SUCCESS)  return(returnError);
        
        // application started and status register can be read correctly
        if (value == 0x90) break;
        
        if (retry-- == 0)
        {
            p_printf(RED, (char*) "can not start application\n");
            return(SENSOR_INTERNAL_ERROR);          
        }
    }
    
    // set drive mode
    if (setDriveMode(settings.mode) != SENSOR_SUCCESS)
    {
        p_printf(RED, (char*) "can not set drive mode to %d\n",settings.mode);
        return(SENSOR_INTERNAL_ERROR);
    }

    // set baseline (if applied)
    if (settings.baseline != 0)
    {
        if (setBaseline(settings.baseline) != SENSOR_SUCCESS)
        {
            p_printf(RED, (char*) "can not set baseline to %lx\n",settings.baseline);
            return(SENSOR_INTERNAL_ERROR);
        }
    }
    
    // enable interrupts
    if (settings.interrupt_gpio > 0) enableInterrupts();

    return returnError;
}

/*********************************************************************
 *
 *   soft_reset on CCS811
 *
 ********************************************************************/
CCS811Core::status CCS811::soft_reset( void )
{
    uint8_t data[4] = {0x11,0xE5,0x72,0x8A};            //software Reset key

    CCS811Core::status returnError = SENSOR_SUCCESS;    //Default return state

    //Reset the device
    returnError = multiWriteRegister(CSS811_SW_RESET, data, 4);
    bcm2835_delay(20);
    
    return(returnError);
}

/**********************************************************************
 *
 *   Sensor functions
 * 
 * Updates the total voltatile organic compounds (TVOC) in 
 * parts per billion (PPB) and the CO2 value
 * Returns no reading
 *
 ********************************************************************/
CCS811Core::status CCS811::readAlgorithmResults(void)
{
    uint8_t data[4];
    
    CCS811Core::status returnError = multiReadRegister(CSS811_ALG_RESULT_DATA, data, 4);
    
    if( returnError != SENSOR_SUCCESS ) return returnError;
    
    // Data order:  co2MSB, co2LSB, tvocMSB, tvocLSB

    CO2 = ((uint16_t)data[0] << 8) | data[1];
    tVOC = ((uint16_t)data[2] << 8) | data[3];
    
    return(returnError);
}

/*********************************************************************
 *
 *  Checks to see if error bit is set 
 *
 ********************************************************************/
bool CCS811::checkForStatusError( void )
{
    uint8_t value;
    
    //return the status bit
    CCS811Core::status returnError = readRegister(CSS811_STATUS, &value );

    if( returnError != SENSOR_SUCCESS ) return 1;

    // return databit 0
    return (value & 1 << 0);
}
/********************************************************************
 *  Checks to see if DATA_READ flag is set in the status register 
 *
 ********************************************************************/
bool CCS811::dataAvailable( void )
{
    uint8_t value;
    CCS811Core::status returnError = readRegister( CSS811_STATUS, &value );
  
    if( returnError != SENSOR_SUCCESS )
    {
        return 0;
    }
    else
    {   // 3rd bit in status
    return (value & 1 << 3);
    }
}

/********************************************************************
 *
 * Checks to see if APP_VALID flag is set in the status register 
 * making sure there is an application program to execute 
 *
 ********************************************************************/
bool CCS811::appValid( void )
{
    uint8_t value;
    CCS811Core::status returnError = readRegister( CSS811_STATUS, &value );
    if( returnError != SENSOR_SUCCESS )
    {
        return 0;
    }
    else
    {
        return (value & 1 << 4);
    }
}

/*********************************************************************
 *
 * read error register
 *
 *********************************************************************/
uint8_t CCS811::getErrorRegister( void )
{
    uint8_t value;
    
    CCS811Core::status returnError = readRegister( CSS811_ERROR_ID, &value );
    
    if( returnError != SENSOR_SUCCESS )
    {
        return 0xFF;
    }
    else
    {
        return value;  //Send all errors in the event of communication error
    }
}

/*********************************************************************
 *
 * read version registers
 *
 * return as :
 * version[0] = HW_version
 * version[1] = Firmware bootloader major / minor
 * version[2] = Firmware bootloader trivial
 * version[3] = Firmware application major / minor
 * version[4] = Firmware application trivial
 * 
 *********************************************************************/
CCS811Core::status CCS811::getversionregisters( uint8_t *version )
{
    CCS811Core::status returnError;
    
    returnError = readRegister( CSS811_HW_VERSION, &version[0]);
    if( returnError != SENSOR_SUCCESS )   return(SENSOR_I2C_ERROR);

    returnError = multiReadRegister( CSS811_FW_BOOT_VERSION, &version[1],2);
    if( returnError != SENSOR_SUCCESS )   return(SENSOR_I2C_ERROR);
    
    returnError = multiReadRegister( CSS811_FW_APP_VERSION, &version[3],2);
    if( returnError != SENSOR_SUCCESS )   return(SENSOR_I2C_ERROR);
    
    return(SENSOR_SUCCESS);
}

/******************************************************************
 *
 * Returns or set the baseline value
 * Used for telling sensor what 'clean' air is
 * You must put the sensor in clean air and record this value
 *
 *******************************************************************/
uint16_t CCS811::getBaseline( void )
{
    uint8_t data[2];

    CCS811Core::status returnError = multiReadRegister(CSS811_BASELINE, data, 2);

    if( returnError != SENSOR_SUCCESS ) return SENSOR_I2C_ERROR;
    else
    {
        uint16_t  baseline = ((uint16_t)data[0] << 8) | data[1];
        return (baseline);
    }
}

CCS811Core::status CCS811::setBaseline( uint16_t input )
{
    uint8_t data[2];
    data[0] = (input >> 8) & 0x00FF;
    data[1] = input & 0x00FF;
    
    CCS811Core::status returnError = multiWriteRegister(CSS811_BASELINE, data, 2);

    return returnError;
}


/********************************************************************
 *
 * Enable ro disable the nINT signal
 *
 ********************************************************************/
//Enable the nINT signal
CCS811Core::status CCS811::enableInterrupts( void )
{
    uint8_t value;
    CCS811Core::status returnError = readRegister( CSS811_MEAS_MODE, &value ); //Read what's currently there
    if(returnError != SENSOR_SUCCESS) return returnError;
        
    value |= (1 << 3); //Set INTERRUPT bit
    
    writeRegister(CSS811_MEAS_MODE, value);
    
    return returnError;
}

//Disable the nINT signal
CCS811Core::status CCS811::disableInterrupts( void )
{
    uint8_t value;
    CCS811Core::status returnError = readRegister( CSS811_MEAS_MODE, &value ); //Read what's currently there
    if( returnError != SENSOR_SUCCESS ) return returnError;
    
    value &= ~(1 << 3); //Clear INTERRUPT bit
    
    returnError = writeRegister(CSS811_MEAS_MODE, value);
    return returnError;
}

/********************************************************************
 *
 * Mode 0 = Idle
 * Mode 1 = read every 1s
 * Mode 2 = every 10s
 * Mode 3 = every 60s
 * Mode 4 = RAW mode
 ********************************************************************/
CCS811Core::status CCS811::setDriveMode(uint8_t mode)
{
    if (mode > 4) mode = 4; //sanitize input
 
    uint8_t value;
    CCS811Core::status returnError = readRegister(CSS811_MEAS_MODE, &value ); //Read what's currently there
    if( returnError != SENSOR_SUCCESS ) return returnError;

    value &= ~(0b00000111 << 4); // Clear DRIVE_MODE bits
    value |= (mode << 4);        // Mask in mode
    
    returnError = writeRegister(CSS811_MEAS_MODE, value);
    if( returnError != SENSOR_SUCCESS ) return returnError;
  
    settings.mode = mode;        // save new mode
    
    return returnError;
}

/**********************************************************************
 * 
 * Given a temp and humidity, write this data to the CSS811 for better compensation
 * This function expects the humidity and temp to come in as floats 
 * 
 **********************************************************************/
CCS811Core::status CCS811::setEnvironmentalData( float relativeHumidity, float temperature )
{
    //Check for invalid temperatures
    if((temperature < -25)||(temperature > 50)) return SENSOR_GENERIC_ERROR;
    
    //Check for invalid humidity
    if((relativeHumidity < 0)||(relativeHumidity > 100)) return SENSOR_GENERIC_ERROR;
    
    uint32_t rH = relativeHumidity * 1000; //42.348 becomes 42348
    uint32_t temp = temperature * 1000;    //23.2 becomes 23200

    char envData[4];

    //Split value into 7-bit integer and 9-bit fractional
    envData[0] = ((rH % 1000) / 100) > 7 ? (rH / 1000 + 1) << 1 : (rH / 1000) << 1;
    envData[1] = 0; //CCS811 only supports increments of 0.5 so bits 7-0 will always be zero
    
    if (((rH % 1000) / 100) > 2 && (((rH % 1000) / 100) < 8))
    {
        envData[0] |= 1; //Set 9th bit of fractional to indicate 0.5%
    }

    temp += 25000; //Add the 25C offset:  0 masp to -25C
    
    //Split value into 7-bit integer and 9-bit fractional
    envData[2] = ((temp % 1000) / 100) > 7 ? (temp / 1000 + 1) << 1 : (temp / 1000) << 1;
    envData[3] = 0;
    if (((temp % 1000) / 100) > 2 && (((temp % 1000) / 100) < 8))
    {
        envData[2] |= 1;  //Set 9th bit of fractional to indicate 0.5C
    }
    CCS811Core::status returnError = multiWriteRegister(CSS811_ENV_DATA, (uint8_t *) envData, 4);
  
    return returnError;
}

/*********************************************************************
 *
 * to support NTC readings
 *
 *********************************************************************/
void CCS811::setRefResistance( float input )
{
    refResistance = input;
}

CCS811Core::status CCS811::readNTC( void )
{
    uint8_t data[4];
    CCS811Core::status returnError = multiReadRegister(CSS811_NTC, data, 4);

    vrefCounts = ((uint16_t)data[0] << 8) | data[1];

    ntcCounts = ((uint16_t)data[2] << 8) | data[3];

    resistance = ((float)ntcCounts * refResistance / (float)vrefCounts);
    
    //Code from Milan Malesevic and Zoran Stupic, 2011,
    //Modified by Max Mayfield,
    temperature = log((long)resistance);
    temperature = 1 / (0.001129148 + (0.000234125 * temperature) + (0.0000000876741 * temperature * temperature * temperature));
    temperature = temperature - 273.15;  // Convert Kelvin to Celsius

    return returnError;
}

float CCS811::getResistance( void )
{
    return resistance;
}

float CCS811::getTemperature( void )
{
    return temperature;
}

/********************************************************************
 *
 * Obtain values that have been set with readAlgorithmResults())
 *
 ********************************************************************/
uint16_t CCS811::getTVOC( void )
{
    return tVOC;
}

uint16_t CCS811::getCO2( void )
{
    return CO2;
}

/*********************************************************************
 *
 * Initialized the BCM2835 library for the raspberry Pi
 *
 *********************************************************************/
CCS811Core::status CCS811Core::bcm_init() 
{
    /* if already initialized */
    if (settings.hw_initialized) return(SENSOR_SUCCESS);
    
    if (!bcm2835_init()) {
        p_printf(RED, (char *) "Can't init bcm2835!\n");
        return(SENSOR_INTERNAL_ERROR);
    }

    // will select I2C channel 0 or 1 depending on board reversion.
    if (!bcm2835_i2c_begin()){
        p_printf(RED, (char *) "Can't setup i2c pin!\n");
        return(SENSOR_INTERNAL_ERROR);
    }

    // set speed
    bcm2835_i2c_set_baudrate(settings.bcm_baudrate *1000);

    // setup the IO pins
    bcm2835_gpio_fsel(settings.reset_gpio, BCM2835_GPIO_FSEL_OUTP);
    bcm2835_gpio_fsel(settings.wake_gpio, BCM2835_GPIO_FSEL_OUTP);
  
    settings.hw_initialized = 1;

    return(SENSOR_SUCCESS);
}


/*********************************************************************
 *
 * Reset BCM 2835 correctlyfor the raspberry Pi
 *
 *********************************************************************/
void CCS811Core::bcm_close()
{
    // reset pins
    bcm2835_i2c_end();

    // restore GPIO
    bcm2835_gpio_fsel(settings.reset_gpio, BCM2835_GPIO_FSEL_INPT);
    bcm2835_gpio_fsel(settings.wake_gpio, BCM2835_GPIO_FSEL_INPT);
    
    // release memory
    bcm2835_close();
    
    settings.hw_initialized = 0;
}

/*********************************************************************
 *  Display in color
 * @param format : Message to display and optional arguments
 *                 same as printf
 * @param level :  1 = RED, 2 = GREEN, 3 = YELLOW 4 = BLUE 5 = WHITE
 * 
 *  if NoColor was set, output is always WHITE.
 *********************************************************************/
void p_printf(int level, char *format, ...)
{
    char    *col;
    int     coll=level;
    va_list arg;
    
    //allocate memory
    col = (char *) malloc(strlen(format) + 20);
    
    if (NoColor) coll = WHITE;
                
    switch(coll)
    {
    case RED:
        sprintf(col,REDSTR, format);
        break;
    case GREEN:
        sprintf(col,GRNSTR, format);
        break;      
    case YELLOW:
        sprintf(col,YLWSTR, format);
        break;      
    case BLUE:
        sprintf(col,BLUSTR, format);
        break;
    default:
        sprintf(col,"%s",format);
    }

    va_start (arg, format);
    vfprintf (stdout, col, arg);
    va_end (arg);

    fflush(stdout);

    // release memory
    free(col);
}
